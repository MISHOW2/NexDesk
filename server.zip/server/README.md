# TicketFlow API

Express API for the TicketFlow helpdesk project.

- **Deployed API:** https://ticket-flow-server-ruddy.vercel.app
- **Health check:** `GET /`

The API is a learning prototype. Tickets are stored in PostgreSQL; users are still stored in process memory, so user data may disappear when the server restarts or serverless instances change. Do not use it for real accounts or confidential support data.

## Requirements

- Node.js
- npm

## Run locally

From the repository root:

```sh
cd server
npm install
```

Create `server/.env` with:

```env
PORT=5000
JWT_SECRET=replace-with-a-long-random-secret
ALLOWED_EMAIL_DOMAIN=example.edu.za
DB_HOST=localhost
DB_PORT=5432
DB_NAME=ticketflow
DB_USER=postgres
DB_PASSWORD=your-postgres-password
```

Create a PostgreSQL database named `ticketflow` in pgAdmin (or use the name of an existing database). Use the host, port, and username shown in your pgAdmin server connection properties, and the password for that PostgreSQL user. Apply the ticket table schema from `server/sql/001_create_tickets.sql` in that database's Query Tool. The server checks its PostgreSQL connection before listening, so it will report a clear error if the connection settings are incomplete or the database cannot be reached. A `DATABASE_URL` or the standard `PGHOST`, `PGPORT`, `PGDATABASE`, `PGUSER`, and `PGPASSWORD` variables can also be used.

Use a private, randomly generated `JWT_SECRET`; never commit your `.env` file. Set `ALLOWED_EMAIL_DOMAIN` to the email domain allowed to register (without the `@`). Then start the API:

```sh
npm run dev
```

The local API is available at `http://localhost:5000`. To run tests:

```sh
npm test
```

## Authentication API

All routes are mounted under `/api/auth`.

| Method | Path | Purpose |
| --- | --- | --- |
| `POST` | `/register` | Register a user |
| `POST` | `/signup` | Alias retained for existing clients |
| `POST` | `/login` | Verify credentials and return a JWT |
| `GET` | `/me` | Validate a JWT and return its user ID and role claims |

### Register

`POST /api/auth/register` (or `/api/auth/signup`) expects JSON:

```json
{
  "name": "Example User",
  "email": "user@example.edu.za",
  "department": "IT",
  "password": "Example123!",
  "rePassword": "Example123!"
}
```

Registration checks the configured email domain, password strength, department, required fields, password confirmation, and duplicate email. Passwords are hashed with bcrypt. Successful registration returns `201` with a confirmation message.

### Login

`POST /api/auth/login` expects:

```json
{
  "email": "user@example.edu.za",
  "password": "Example123!"
}
```

Successful login returns `200` with the user (excluding the password hash) and a JWT that expires after one hour. Invalid credentials return a generic authentication error.

### Current user

Send the token from login in the `Authorization` header:

```http
Authorization: Bearer <token>
```

`GET /api/auth/me` validates the token using `JWT_SECRET`.

Registration is limited to five attempts per two-minute window. The same limiter applies to both `/register` and `/signup`.

## Ticket API status

Authenticated ticket endpoints are:

| Method | Path | Purpose |
| --- | --- | --- |
| `POST` | `/api/tickets` | Create a ticket |
| `GET` | `/api/tickets` | List tickets |
| `GET` | `/api/tickets/:ticket_id` | Retrieve one ticket |
| `PATCH` | `/api/tickets/:ticket_id` | Update a ticket's `status` |

## Known limitations

- User data still uses an in-memory array; it is not durable.
- Ticket `created_by` and `assigned_to` are numeric IDs but do not yet have foreign keys because users have not been migrated to PostgreSQL.
- The seeded demo users have placeholder password hashes and cannot be used to log in.
- Ticket endpoints have not yet been integration-tested against a live PostgreSQL database.
- This API is not connected to the demo frontend.
- Configure `JWT_SECRET` and `ALLOWED_EMAIL_DOMAIN` in the hosting provider's environment settings as well as locally. A local `.env` does not configure the deployed service.
