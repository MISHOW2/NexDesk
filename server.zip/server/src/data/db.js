import { Pool } from "pg";

let pool;

function getPool() {
  if (!pool) {
    const connectionString = process.env.DATABASE_URL;
    const database = process.env.DB_NAME || process.env.PGDATABASE;
    const user = process.env.DB_USER || process.env.PGUSER;

    if (!connectionString && (!database || !user)) {
      throw new Error(
        "Set DATABASE_URL or configure DB_NAME and DB_USER in .env"
      );
    }

    const config = connectionString
      ? { connectionString }
      : {
          host: process.env.DB_HOST || process.env.PGHOST || "localhost",
          port: Number(process.env.DB_PORT || process.env.PGPORT || 5432),
          database,
          user,
          password: process.env.DB_PASSWORD || process.env.PGPASSWORD,
        };

    pool = new Pool(config);
    pool.on("error", (error) => {
      console.error("Unexpected PostgreSQL pool error:", error);
    });
  }

  return pool;
}

export function query(text, values) {
  return getPool().query(text, values);
}