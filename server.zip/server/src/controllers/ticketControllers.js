import * as ticketRepository from "../repositories/ticketRepository.js";
import { validateFieldInputs } from "../validation/validateFieldInputs.js";

export const createTicketHandler = async (req, res) => {
  const { title, description, priority, categoryId } = req.body;

  try {
    validateFieldInputs({ title, description, priority, categoryId });
  } catch (error) {
    return res.status(400).json({ message: error.message });
  }

  try {
    const ticket = await ticketRepository.insertTicket({
      title,
      description,
      priority,
      categoryId,
      createdBy: req.user.user_id
    });

    res.status(201).json({ message: "Ticket created", ticket });
  } catch (error) {
    return res.status(500).json({
      message: "Unable to create ticket",
      error: error.message,
    });
  }
};

export const getTickets = async (req, res) => {
  try {
    const allTickets = await ticketRepository.getAllTickets();

    if (allTickets.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No tickets found",
      });
    }

    return res.status(200).json({
      success: true,
      data: allTickets,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

export const getSingleTicket = async (req, res) => {
  try {
    const ticket = await ticketRepository.getTicketById(req.params.ticket_id);
    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: "Ticket not found",
      });
    }

    return res.status(200).json({ success: true, data: ticket });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

export const updateTicketStatus = async (req, res) => {
  try {
    const { ticket_id: ticketId } = req.params;
    const { status } = req.body;

    validateFieldInputs({ status });
    const ticket = await ticketRepository.updateStatus(ticketId, status);
    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: "Ticket not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: ticket
    });
  } catch (error) {
    return res.status(error.code ? 500 : 400).json({
      success: false,
      message: error.message
    });
  }
};